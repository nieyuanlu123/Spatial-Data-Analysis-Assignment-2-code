library(terra)
library(sf)
library(tmap)
library(dplyr)

setwd('/桌面/a2')
idn=st_read('idn_adm_bps_20200401_shp/idn_admbnda_adm0_bps_20200401.shp')
idn1=st_read('idn_adm_bps_20200401_shp/idn_admbnda_adm1_bps_20200401.shp')
View(idn1)
plants=read.csv('plants.csv')
plants <- plants[complete.cases(plants$latitude, plants$longitude), ]
install.packages("ggspatial")
install.packages("patchwork")
library(ggplot2)
library(ggspatial)
library(patchwork)

# 创建颜色分类
type_colors <- c("solar" = "pink", "Hydro" = "cadetblue3","Geothermal" = "cornflowerblue","wind" = "gold")



# 创建 ggplot
ggplot() +
  geom_sf(data = idn, color = "darkgrey") +
  geom_sf(data=idn1,color="darkblue")+
  geom_point(data = plants, 
             aes(x = longitude, y = latitude, 
                 color = type, size = capacity_mw, shape = status),
             ) +
  scale_color_manual(values = type_colors) +
  labs(title = "Renewable Power Plants in Indonesia",
       x = "Longitude",
       y = "Latitude") +
  theme_minimal()+
  
  
  annotation_north_arrow()+ annotation_scale()

install.packages("ncdf4")
library(ncdf4) 
solar <- nc_open("data.nc" )
solar
lon <- ncvar_get(solar, "longitude")
lat <- ncvar_get(solar, "latitude")
time <- ncvar_get(solar, "time")
time
dim(time)
tunits <- ncatt_get(solar,"time","units")
install.packages("chron")
library(chron)

tustr <- strsplit(tunits$value, " ") 
tdstr <- strsplit(unlist(tustr)[3], "-") 
tyear <- as.integer(unlist(tdstr)[1]) 
tmonth <- as.integer(unlist(tdstr)[2])
tday <- as.integer(unlist(tdstr)[3])

chron(time/24, origin=c(tmonth, tday, tyear) )
ssrd_array <- ncvar_get(solar,"ssrd")
dim(ssrd_array)
dlname <- ncatt_get(solar,"ssrd","long_name")
dunits <- ncatt_get(solar,"ssrd","units")
fillvalue <- ncatt_get(solar,"ssrd","_FillValue")
install.packages("lattice")
library(lattice)
install.packages("RColorBrewer")
library(RColorBrewer)
ssrd_slice <- ssrd_array[,,10]#时间切片，取了第二个时间点
length(na.omit(as.vector(ssrd_slice))) /length(as.vector(ssrd_slice))
dim(ssrd_slice )
image(ssrd_slice, col=rev(brewer.pal(10,"RdBu")) )#第二个时间切片的可视化
max_rad <- max(ssrd_slice, na.rm=TRUE)
max_rad

lonlat <- as.matrix( (expand.grid(lon, lat)))
dim(lonlat)
ssrd_vec <- as.vector( ssrd_slice) 
length(ssrd_vec)
ssrd_df <- data.frame( cbind( lonlat,ssrd_vec  ))
colnames(ssrd_df) <- c("lon", "lat", "ssrd")
ssrd_df_value <- na.omit (ssrd_df)
head(ssrd_df_value, 3) 


library(sf)
ssrd_sf<- st_as_sf( ssrd_df_value, coords = c(  "lon", "lat")  )
st_crs(ssrd_sf) <- 4326 
ssrd_sf <- st_transform(ssrd_sf, 4326 )

library(tmap)
tmap_mode("view")
tm_shape(ssrd_sf)+
  tm_dots(col="ssrd", style = "quantile", size=.001, palette = "viridis")#第二个时间切片的交互式可视化
ncatt_get(solar,"ssrd","units")
radiation_to_power <- function(G, A=1, r=0.175, p=0.6, hours=1){
  kWh <- G * A * r * p * (hours/3600) / 1000
  return(kWh)
}
ssrd_kwh <- as.data.frame (radiation_to_power (ssrd_df_value))
ssrd_df_value <- cbind(ssrd_df_value,ssrd_kwh$ssrd)
colnames(ssrd_df_value) [4] <- 'ssrd_kwh'
ssrd_sf$ssrd_kwh = ssrd_kwh$ssrd

tm_shape(ssrd_sf)+
  tm_dots(col="ssrd_kwh", style = "quantile", size=.001, palette = "YlOrRd")

ssrd_sf = st_transform(ssrd_sf, 4326)
idn = st_transform(idn, st_crs(ssrd_sf))

coor = as.data.frame(st_coordinates(ssrd_sf))
View(ssrd_sf)
ssrd_sf$x = coor$X
ssrd_sf$y = coor$Y
ssrd_nogeom = st_drop_geometry(ssrd_sf) #get rid of geometry but keep all other attributes
ssrd_nogeom=na.omit(ssrd_nogeom)

install.packages("gstat")
library(gstat)
gs <- gstat(formula=ssrd~1, locations=~x+y, data=ssrd_nogeom, nmax=Inf, set=list(idp=5)) #data should be in data frame format
gs
st_bbox(idn)
library(raster)

# 创建 spatial raster 对象
raster_template <- raster(extent(95.01079, 141.01940, -11.00762, 6.07693),
                         resolution = 0.05,
                         crs = st_crs(idn)$wkt)
raster_template
idw <- interpolate(raster_template, gs,z = ssrd_nogeom$ssrd, debug.level=0)
names(idw)                   
plot(idw$x)
idw_mask <- mask(idw, idn)
plot(idw_mask$x)
names(idw_mask) = c( "predicted_ssrd" )
tmap_mode("view")
tm_shape(idw_mask$predicted_ssrd) + 
  tm_raster(col="predicted_ssrd", style = "quantile", n = 10, palette= "Reds", legend.show = TRUE)+ tm_scale_bar(position = c("right", "bottom"))

radiation_to_power <- function(G, A=1, r=0.175, p=0.6, hours=1){
  kWh <- G * A * r * p * (hours/3600) / 1000
  return(kWh)
}
idw_mask_kwh=radiation_to_power (idw_mask$predicted_ssrd)
names(idw_mask_kwh)=c("ssrd_kwh")
r_matrix=matrix(c(0.2,0.3,0.5,
                  0.3,0.4,1.5,
                  0.4,0.5,2.5,
                  0.5,0.65,3.5,
                  0.65,Inf,4.5),
                ncol=3,byrow=TRUE)
idw_mask_kwh_c=reclassify(idw_mask_kwh,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "idw_mask_kwh_c.tif"
writeRaster(idw_mask_kwh_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(idw_mask_kwh_c)+
  tm_raster(palette = "YlOrRd",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Radiation(kwh)",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )
RMSE <- function(observed, predicted) {
  sqrt(mean((predicted - observed)^2, na.rm=TRUE))
}

null <- RMSE(ssrd_nogeom$ssrd, idw_mask$predicted_ssrd)
null #RMSE值为1572409

n_idp = 20 #examine power ranging from 1 to 20
n_fold =10

rmse <- rep(NA, n_fold) #generate 10 NA
set.seed(7713)
kf <- sample(1:n_fold, nrow(ssrd_nogeom), replace=TRUE)
va = data.frame( c(1:n_idp), NA)
colnames(va) =c("idp","rmse") 



for (j in 1:n_idp) 
{
  for (i in 1:n_fold) {
    test <- ssrd_nogeom[kf == 1, ]
    train <- ssrd_nogeom[kf != 1, ]
    gs <- gstat(formula=ssrd~1, locations=~x+y, data=train, nmax=Inf, set=list(idp=j))
    pre = predict(gs, test, debug.level=0 )
    rmse[i] <- RMSE(test$ssrd, pre$var1.pred)
  }
  va[j,2] = (mean(rmse) )
}
va[which(va$rmse==min(va)),]

library(ggplot2)
ggplot(va) +
  geom_point(aes(x = idp, y= rmse))+
  geom_hline(yintercept=min(va), linetype="dashed", color = "red")+
  theme_classic()

