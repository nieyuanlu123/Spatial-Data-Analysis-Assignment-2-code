setwd('D:/桌面/a2')
library(terra)
library(raster)
library(sf)
library(tmap)
library(dplyr)
idn=st_read('idn_adm_bps_20200401_shp/idn_admbnda_adm0_bps_20200401.shp')
View(idn)
st_bbox(idn)
r<-rast('IDN_alt/IDN_alt.vrt')
r_mask <- mask(r, idn)
r_matrix=matrix(c(-Inf,300,4.5,
                  300,700,3.5,
                  700,1100,2.5,
                  1100,1500,1.5,
                  1500,Inf,0.5),
                ncol=3,byrow=TRUE)
r_mask_c=classify(r_mask,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "r_mask_c.tif"
writeRaster(r_mask_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tmap_mode("plot") 
tm_shape(r_mask_c)+
  tm_raster(palette = "viridis",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Elevation",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )

s <- terrain(r_mask, unit = "degrees")
r_matrix=matrix(c(0,2,4.5,
                  2,4,3.5,
                  4,6,2.5,
                  6,8,1.5,
                  8,Inf,0.5),
                ncol=3,byrow=TRUE)
s_c=classify(s,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "s_c.tif"
writeRaster(s_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(s_c)+tm_raster(palette="Spectral", legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Slope",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )

protect0=st_read('WDPA_WDOECM_Jan2024_Public_IDN_shp_0/WDPA_WDOECM_Jan2024_Public_IDN_shp-points.shp')
protect1=st_read('WDPA_WDOECM_Jan2024_Public_IDN_shp_1/WDPA_WDOECM_Jan2024_Public_IDN_shp-points.shp')
protect2=st_read('WDPA_WDOECM_Jan2024_Public_IDN_shp_2/WDPA_WDOECM_Jan2024_Public_IDN_shp-points.shp')
protect00=st_read('WDPA_WDOECM_Jan2024_Public_IDN_shp_0/WDPA_WDOECM_Jan2024_Public_IDN_shp-polygons.shp')
protect11=st_read('WDPA_WDOECM_Jan2024_Public_IDN_shp_1/WDPA_WDOECM_Jan2024_Public_IDN_shp-polygons.shp')
protect22=st_read('WDPA_WDOECM_Jan2024_Public_IDN_shp_2/WDPA_WDOECM_Jan2024_Public_IDN_shp-polygons.shp')
merged_points <- rbind(protect0, protect1, protect2)
merged_polygons <- rbind(protect00, protect11, protect22)
output_points <- "/Users/17369/Desktop/a2/points.shp"
output_polygons <- "/Users/17369/Desktop/a2/polygons.shp"
st_write(merged_points, output_points)
st_write(merged_polygons, output_polygons)

library(ggplot2)
library(ggspatial)
library(patchwork)
ggplot() +
  geom_sf(data = idn, fill = 'darkgrey') +
  geom_sf(data = merged_polygons, fill = "forestgreen", color = "forestgreen") +
  labs(title = "Protected Area in Indonesia",
       x = "Longitude",
       y = "Latitude") +
  theme_minimal()+
  annotation_north_arrow()+ annotation_scale()

road=st_read('IDN_rds/IDN_roads.shp')
st_bbox(idn)
st_bbox(road)
extent <- extent(c( 95.044136,141.023288,-10.899222,5.889528 ))
road_grid <- raster(extent, resolution = c(0.2, 0.2))
roads_raster <- rasterize(road, road_grid)
distance_road <- distance(roads_raster)
distance_road_mask=mask(distance_road,idn)
road_high_res = disaggregate(distance_road_mask, fact=50,method="bilinear")
r_matrix=matrix(c(-Inf,10000,4.5,
                  10000,20000,3.5,
                  20000,40000,2.5,
                  40000,80000,1.5,
                  80000,Inf,0.5),
                ncol=3,byrow=TRUE)
road_high_res_c=reclassify(road_high_res,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "road_high_res_c.tif"
writeRaster(road_high_res_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(road_high_res_c)+
  tm_raster(palette = "PuBuGn",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Distance from Roads",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )

tm_shape(idn)+tm_borders(col='grey')+
  tm_fill(col='darkblue')+
  tm_shape(road)+tm_lines(col='lightblue')+
  tm_scale_bar(position = c(0, 0), width = 0.2)


settlement=raster('population_2020.tif')
res(settlement)
scale_factor <- 60
settlement_downsampled <- aggregate(settlement, fact = scale_factor, fun = mean)
settlement_downsampled=mask(settlement_downsampled,idn)
r_matrix=matrix(c(-Inf,0.005,4.5,
                  0.005,0.01,3.5,
                  0.01,0.02,2.5,
                  0.02,0.04,1.5,
                  0.04,1,0.5),
                ncol=3,byrow=TRUE)
settlement_downsampled_c=reclassify(settlement_downsampled,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "settlement_downsampled_c.tif"
writeRaster(settlement_downsampled_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
  tm_shape(settlement_downsampled_c)+
  tm_raster(palette = "Set3",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Population",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )

line=read_sf('grid.geojson')

target_crs <- st_crs(idn)
line <- st_transform(line, crs = target_crs)
st_bbox(line)
extent <- extent(c(  95.34192,140.79256,-10.35373,5.65146))
line_grid <- raster(extent, resolution = c(0.2, 0.2))
lines_raster <- rasterize(line, line_grid)
distance_line <- distance(lines_raster)
distance_line_mask=mask(distance_line,idn)
line_high_res = disaggregate(distance_line_mask, fact=50,method="bilinear")
r_matrix=matrix(c(-Inf,10000,4.5,
                  10000,30000,3.5,
                  30000,60000,2.5,
                  60000,100000,1.5,
                  100000,Inf,0.5),
                ncol=3,byrow=TRUE)
line_high_res_c=reclassify(line_high_res,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "line_high_res_c.tif"
writeRaster(line_high_res_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(line_high_res_c)+
  tm_raster(palette = "Oranges",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Distance from Transmission Lines",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )

tm_shape(idn)+tm_borders(col='gold')+
  tm_fill(col='gold3')+
  tm_shape(line)+tm_lines(col='red')+
  tm_scale_bar(position = c(0, 0), width = 0.2)


temperature=raster('wc2.1_10m_tavg/wc2.1_10m_tavg.tif')
temperature_high_res = disaggregate(temperature, fact=50,method="bilinear")
temperature_cropped=mask(temperature_high_res,idn)
r_matrix=matrix(c(0.00,15.00,4.5,
                  15.00,20.00,3.5,
                  20.00,23.00,2.5,
                  23.00,27.00,1.5,
                  27.00,30.00,0.5),
                ncol=3,byrow=TRUE)
temperature_high_res_c=reclassify(temperature_high_res,r_matrix)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "temperature_high_res_c.tif"
writeRaster(temperature_high_res_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(temperature_cropped)+
  tm_raster(palette = "YlGnBu",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Average Temperature",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.2,  
  )
library(raster)
tem=raster("temperature_high_res_.tif")
tm_shape(tem)+
  tm_raster(palette = "YlGnBu",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Average Temperature",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.2,  
    legend.height = 0.05,  
  )
suitability=raster("suitability.tif")
r_matrix=matrix(c(1,1.75,0.5,
                  1.75,2.5,1.5,
                  2.5,3.25,2.5,
                  3.25,3.75,3.5,
                  3.75,4.5,4.5),
                ncol=3,byrow=TRUE)
suitability_c=reclassify(suitability,r_matrix)
tm_shape(suitability_c)+
  tm_raster(palette = "YlGnBu",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Suitability",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.3,  
    legend.height = 0.05,  
  )
protect_area=raster("protect_area.tif")
mask <- is.na(protect_area)
mask[mask == 0] <- NA
plot(protect_area)
plot(mask)
maskk=mask(mask,idn)
plot(maskk)
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "exclude_protect_area.tif"
writeRaster(maskk, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
new_extent <- c(95.01079, 141.0108, -11.00762, 6.092385 )
maskk <- setExtent(maskk, extent(new_extent))
maskk=resample(maskk,suitability)
suitability_protect_area=mask(suitability_c,maskk)
plot(suitability_protect_area)


suitability_protect_area=raster("suitability_exclude_protect_area.tif")
# 计算所选区域的总面积
selected_area <- sum(res(suitability_protect_area)[1] * res(suitability_protect_area)[2] * (!is.na(values(suitability_protect_area)) & values(suitability_protect_area) == 4.5))
selected_area0 <- sum(res(suitability)[1] * res(suitability)[2] * (!is.na(values(suitability))))

#电厂选址
suitability_protect_area=raster("suitability_exclude_protect_area.tif")
suitability_mask=mask(suitability,suitability_protect_area)
max_values <- sort(values(suitability_mask), decreasing = TRUE)[1:14]
max_cells <- which(values(suitability_mask) %in% max_values)
max_coordinates <- xyFromCell(suitability_mask, max_cells)
data=read.csv("plants_predicted.csv")
View(data)
sf_data=st_as_sf(data,
                   coords=c("x","y"),crs=st_crs(4326))
View(sf_data)
line = st_transform(line, 4326)
sf_data1 <- st_sf(geometry = st_sfc(st_point(c(103.6358, -4.082615))), crs = 4326)
sf_data2 <- st_sf(geometry = st_sfc(st_point(c(107.3358, -6.832615))), crs = 4326)
sf_data3 <- st_sf(geometry = st_sfc(st_point(c(106.5858, -7.032615))), crs = 4326)
sf_data4 <- st_sf(geometry = st_sfc(st_point(c(106.6858, -7.032615))), crs = 4326)
sf_data5 <- st_sf(geometry = st_sfc(st_point(c(107.0858, -7.032615))), crs = 4326)
sf_data6 <- st_sf(geometry = st_sfc(st_point(c(107.1358, -7.032615))), crs = 4326)
sf_data7 <- st_sf(geometry = st_sfc(st_point(c(107.2358, -7.032615))), crs = 4326)
sf_data8 <- st_sf(geometry = st_sfc(st_point(c(106.6858, -7.082615))), crs = 4326)
sf_data9 <- st_sf(geometry = st_sfc(st_point(c(107.0858, -7.082615))), crs = 4326)
sf_data10 <- st_sf(geometry = st_sfc(st_point(c(107.1858, -7.082615))), crs = 4326)
sf_data11 <- st_sf(geometry = st_sfc(st_point(c(106.9358, -7.132615))), crs = 4326)
sf_data12 <- st_sf(geometry = st_sfc(st_point(c(114.2358, -7.932615))), crs = 4326)
sf_data13 <- st_sf(geometry = st_sfc(st_point(c(124.3858, -9.682615))), crs = 4326)
sf_data14 <- st_sf(geometry = st_sfc(st_point(c(124.3358, -9.832615))), crs = 4326)
distances1=min(st_distance(sf_data1,line))
distances2=min(st_distance(sf_data2,line))
distances3=min(st_distance(sf_data3,line))
distances4=min(st_distance(sf_data4,line))
distances5=min(st_distance(sf_data5,line))
distances6=min(st_distance(sf_data6,line))
distances7=min(st_distance(sf_data7,line))
distances8=min(st_distance(sf_data8,line))
distances9=min(st_distance(sf_data9,line))
distances10=min(st_distance(sf_data10,line))
distances11=min(st_distance(sf_data11,line))
distances12=min(st_distance(sf_data12,line))
distances13=min(st_distance(sf_data13,line))
distances14=min(st_distance(sf_data14,line))

tm_shape(suitability_protect_area)+
  tm_raster(palette = "YlGnBu",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_shape(sf_data)+
  tm_dots(col='red',size=0.05)+
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_compass(position=c(0.03,0.1),size=1)+
  tm_layout(
    main.title="14 Predicted Plants (Red dots)",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.3,  
    legend.height = 0.05,  
  )
export_path <- "/Users/17369/Desktop/a2"
export_filename <- "suitability_exclude_protect_area.tif"
writeRaster(suitability_protect_area, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)

selected_cells <- suitability_protect_area[suitability_protect_area[] >= 3.5]

selected_area <- sum(res(suitability_protect_area)[1] * res(suitability_protect_area)[2] * (!is.na(values(suitability_protect_area)) & values(suitability_protect_area) >= 3.5))
selected_area

wind_speed=raster("IDN_wind-speed_100m.tif")
res(wind_speed)
extent(wind_speed)
scale_factor <- 20
settlement_downsampled <- aggregate(wind_speed, fact = scale_factor, fun = mean)
wind_speed_mask=mask(settlement_downsampled,idn)
r_matrix=matrix(c(0,2,0.5,
                  2,3,1.5,
                  3,4,2.5,
                  4,6,3.5,
                  6,8,4.5),
                ncol=3,byrow=TRUE)
wind_speed_mask_c=reclassify(wind_speed_mask,r_matrix)
export_path <- "/桌面/a2"
export_filename <- "wind_speed_mask_c.tif"
writeRaster(wind_speed_mask_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
wind_speed_mask_c=raster("wind_speed_mask_c.tif")
tm_shape(wind_speed_mask_c)+
  tm_raster(n=5,palette = "Blues",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_compass(position=c(0.03,0.1),size=1)+
  tm_layout(
    main.title="Wind Speed",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.6,  
    legend.height = 0.05,  
  )


wind_power=raster("IDN_power-density_100m.tif")
scale_factor <- 20
wind_power_downsampled <- aggregate(wind_power, fact = scale_factor, fun = mean)
wind_power_mask=mask(wind_power_downsampled,idn)
r_matrix=matrix(c(0,20,0.5,
                  20,40,1.5,
                  40,60,2.5,
                  60,100,3.5,
                  100,600,4.5),
                ncol=3,byrow=TRUE)
wind_power_mask_c=reclassify(wind_power_mask,r_matrix)
export_path <- "/桌面/a2"
export_filename <- "wind_power_mask_c.tif"
writeRaster(wind_power_mask_c, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(wind_power_mask_c)+
  tm_raster(palette = "Blues",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Wind Power Density",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.6,  
    legend.height = 0.05,  
  )

wind_suitability=raster("suitability_wind.tif")

res(wind_suitability)
res(suitability)
maskkk=raster("exclude_protect_area.tif")
new_extent <- c(95.21079 , 141.0108, -11.10762, 5.892385  )
wind_suitability <- setExtent(wind_suitability, extent(new_extent))
maskkk=resample(maskkk,wind_suitability)
wind_suitability_mask=mask(wind_suitability,maskkk)
export_path <- "/桌面/a2"
export_filename <- "Wind_suitability_exclude_protected_area.tif"
writeRaster(wind_suitability_mask, file.path(export_path, export_filename), format = "GTiff", overwrite = TRUE)
tm_shape(wind_suitability_mask)+
  tm_raster(palette = "BuPu",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_layout(
    main.title="Wind suitability exclude protect area",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.8,  
    legend.height = 0.05,  
  )

wind123=raster("Wind_suitability_exclude_protected_area.tif")
r_matrix=matrix(c(0,1,1,
                  1,2,2,
                  2,3,3,
                  3,4,4,
                  4,5,5),
                ncol=3,byrow=TRUE)
wind123=reclassify(wind123,r_matrix)
selected_area <- sum(res(wind123)[1] * res(wind123)[2] * (!is.na(values(wind123)) & values(wind123) == 5))


max_values <- sort(values(wind123), decreasing = TRUE)[1:67]
max_cells <- which(values(wind123) %in% max_values)
max_coordinates <- xyFromCell(wind123, max_cells)
data=read.csv("new wind power plants.csv")
View(data)
sf_data=st_as_sf(data,
                 coords=c("x","y"),crs=st_crs(4326))
View(sf_data)
line = st_transform(line, 4326)
min_distances <- numeric(length(sf_data))

for (i in 1:nrow(sf_data)) {
  
  min_distances[i] <- min(st_distance(sf_data[i,], line))
}

min_distances[69]

sum(min_distances)


tm_shape(wind123)+
  tm_raster(palette = "Blues",legend.show = TRUE, labels = c("1", "2", "3", "4", "5"))+ 
  tm_shape(sf_data)+
  tm_dots(col='gold2',size=0.05)+
  tm_scale_bar(position = c(0, 0), width = 0.2) +
  tm_compass(position=c(0.03,0.15),size=0.5)+
  tm_layout(
    main.title="67 Predicted Wind Plants (Yellow dots)",
    legend.outside = TRUE,
    legend.position = c("left", "bottom"), 
    legend.width = 0.3,  
    legend.height = 0.05,  
  )
